import mock from './mock';
export default mock; // 导入同级下mock.js的内容，并且导出

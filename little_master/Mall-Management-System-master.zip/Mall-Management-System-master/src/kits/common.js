export default {
    apidomain:"http://wxtest.centaline.com.cn/api/api?"
}
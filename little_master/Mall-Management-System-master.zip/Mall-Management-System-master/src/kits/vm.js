import Vue from "Vue";

export const COUNTSTR="inputNumberCount";
export var vm =new Vue();

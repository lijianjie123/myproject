# Mall-Management-System
使用Vue技术搭建商城管理系统，实现新闻列表、商品列表、购物车、提交评论等功能

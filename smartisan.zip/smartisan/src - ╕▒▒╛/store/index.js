import Vue from "vue"; //引入 vue   from后边的"vue" 要小写
import Vuex from "vuex";
Vue.use(Vuex);

export default store; //把store暴露出去，让我们能够拿到它
